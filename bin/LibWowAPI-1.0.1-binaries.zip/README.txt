LibWowAPI
Version 1.0.1
by Ronald M. Clifford (roncli@roncli.com)

This source code is released under the GNU Lesser General Public License (LGPL) Version 3.0.

LibWowAPI is a library for the .NET framework that interfaces with the Blizzard World of Warcraft API. The Blizzard World of Warcraft API (https://github.com/blizzard/api-wow-docs) is an online API that interfaces with World of Warcraft.

For more information, please visit the LibWowAPI Github website at https://github.com/roncli/LibWowAPI.
